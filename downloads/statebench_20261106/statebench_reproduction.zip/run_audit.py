"""Replay official StateBench traces; no language model is called.

This is a deterministic deletion audit, not a reproduction of model evaluations.
The upstream generator/evaluator are imported unchanged at the pinned commit.
"""
from __future__ import annotations

import csv
import hashlib
import html
import json
import platform
import random
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from state_bench.config import load_formatter
from state_bench.generation import derive_variants, generate_periodic_source
from state_bench.model import AssignConstant, AssignIncrement, AssignVariable, QueryMode
from state_bench.rendering import render_instance
from state_bench.semantics import evaluate

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "vendor" / "state-bench"
RESULTS = ROOT / "results"
PIN = "5b333b8d426638d8825f40efe8a508c20eb85730"
SEEDS = tuple(range(32))
LENGTHS = (8, 32, 128, 512)
NUM_VARIABLES = 5
NUM_VALUES = 32


def json_write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def own_replay(operations, *, omit=None):
    """Small independent interpreter, including uninitialized prefix snapshots."""
    state = [None] * (NUM_VARIABLES + 1)
    snapshots = []
    for index, op in enumerate(operations):
        if index != omit:
            if isinstance(op, AssignConstant):
                state[op.target] = op.value
            elif isinstance(op, AssignVariable):
                assert state[op.source] is not None
                state[op.target] = state[op.source]  # eager value copy
            elif isinstance(op, AssignIncrement):
                assert state[op.target] is not None
                state[op.target] = (state[op.target] + op.delta) % NUM_VALUES
            else:
                raise TypeError(op)
        snapshots.append(tuple(state))
    return snapshots


def official_replay(instance, operations):
    return evaluate(num_variables=instance.num_registers,
                    num_values=instance.num_values, operations=operations)


def op_text(op):
    name = lambda n: "TMP" if n == NUM_VARIABLES else chr(97+n)
    if isinstance(op, AssignConstant):
        return f"{name(op.target)} <- {op.value};"
    if isinstance(op, AssignVariable):
        return f"{name(op.target)} <- {name(op.source)};"
    return f"{name(op.target)} <- ({name(op.target)} + {op.delta}) mod {NUM_VALUES};"


def eager_copy_check():
    # 2 ordinary registers, no TMP: changing b later must not change a.
    ops = (AssignConstant(0, 2), AssignConstant(1, 5),
           AssignVariable(0, 1), AssignConstant(1, 9))
    result = evaluate(num_variables=2, num_values=32, operations=ops)
    assert result == (5, 9)
    return {"operations": [op.to_record() for op in ops],
            "expected": [5, 9], "actual": list(result),
            "explanation": "a copies b's value 5 immediately; b's later 9 does not change a."}


def main():
    RESULTS.mkdir(exist_ok=True)
    commit = subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip()
    assert commit == PIN
    formatter = load_formatter(REPO / "configs/formats/integer-code-modular.yaml")
    eager = eager_copy_check()
    summary = defaultdict(Counter)
    invariants = Counter()
    fixture = None
    csv_path = RESULTS / "omission_replays.csv"
    sources_path = RESULTS / "canonical_family_sets.jsonl"
    with csv_path.open("w", newline="", encoding="utf-8") as cf, sources_path.open("w", encoding="utf-8") as jf:
        fields = ["seed", "extra_assignments", "family", "source_instance_id",
                  "operation_index_0based", "update_index_1based", "omitted_op_type",
                  "omitted_target", "ordinary_mismatches", "all_register_mismatches"]
        writer = csv.DictWriter(cf, fieldnames=fields)
        writer.writeheader()
        for length in LENGTHS:
            for seed in SEEDS:
                kwargs = dict(num_variables=NUM_VARIABLES, num_values=NUM_VALUES,
                              min_extra_assignments=length, max_extra_assignments=length,
                              min_aperiodic_constants=1, max_aperiodic_constants=1,
                              distinct_initial_values=True, query_mode=QueryMode.ALL)
                source = generate_periodic_source(**kwargs, rng=random.Random(seed))
                repeated = generate_periodic_source(**kwargs, rng=random.Random(seed))
                assert source == repeated
                invariants["deterministic_source_regeneration"] += 1
                variants = derive_variants(source)
                snapshots = {v.complexity.value: own_replay(v.operations) for v in variants}
                assert snapshots["periodic"] == snapshots["aperiodic"] == snapshots["solvable"]
                invariants["three_family_stepwise_state_equality"] += len(source.operations)
                initial_count = source.num_initial_assignments
                assert initial_count == NUM_VARIABLES + 1
                assert len(source.operations) == initial_count + length
                assert all(isinstance(op, AssignConstant) for op in source.operations[:initial_count])
                init_state = snapshots["periodic"][initial_count - 1]
                renders = []
                for instance in variants:
                    family = instance.complexity.value
                    assert len(instance.operations) == len(source.operations)
                    assert tuple(op.target for op in instance.operations) == tuple(op.target for op in source.operations)
                    assert instance.query == source.query
                    assert instance.temporary_variable == source.temporary_variable
                    assert tuple(snapshots[family][-1]) == instance.final_state
                    assert official_replay(instance, instance.operations) == instance.final_state
                    invariants["official_and_independent_final_evaluator_agreement"] += 1
                    if family == "r-trivial":
                        assert all(state == init_state for state in snapshots[family][initial_count - 1:])
                        invariants["r_trivial_first_value_invariant"] += 1
                    rendered = render_instance(instance, formatter, rng=random.Random(991))
                    renders.append(rendered)
                    key = (length, family)
                    summary[key]["source_count"] += 1
                    for index in range(initial_count, len(instance.operations)):
                        omitted = instance.operations[:index] + instance.operations[index + 1:]
                        observed = official_replay(instance, omitted)
                        independently_observed = own_replay(instance.operations, omit=index)[-1]
                        assert observed == independently_observed
                        mismatches = sum(a != b for a,b in zip(observed[:NUM_VARIABLES], instance.final_state[:NUM_VARIABLES]))
                        all_mismatches = sum(a != b for a,b in zip(observed, instance.final_state))
                        row = dict(seed=seed, extra_assignments=length, family=family,
                                   source_instance_id=source.instance_id, operation_index_0based=index,
                                   update_index_1based=index-initial_count+1,
                                   omitted_op_type=instance.operations[index].to_record()["op"],
                                   omitted_target=instance.operations[index].target,
                                   ordinary_mismatches=mismatches,
                                   all_register_mismatches=all_mismatches)
                        writer.writerow(row)
                        summary[key]["omission_replays"] += 1
                        summary[key]["replays_with_ordinary_error"] += mismatches > 0
                        summary[key]["ordinary_mismatch_sum"] += mismatches
                        summary[key]["replays_with_any_register_error"] += all_mismatches > 0
                        summary[key]["all_register_mismatch_sum"] += all_mismatches
                        summary[key][f"ordinary_mismatch_{mismatches}"] += 1
                        invariants["omission_official_independent_agreement"] += 1
                assert len({r.surface_variables for r in renders}) == 1
                assert len({r.surface_values for r in renders}) == 1
                invariants["four_family_structure_and_surface_alignment"] += 1
                jf.write(json.dumps({"seed": seed, "extra_assignments": length,
                                     "source_instance_id": source.instance_id,
                                     "variants": [v.to_record() for v in variants]}) + "\n")
                if length == 8 and seed == 0:
                    fixture = {"seed": seed, "extra_assignments": length,
                               "scope": "Actual upstream generator output; no language model.",
                               "source_instance_id": source.instance_id,
                               "num_variables": NUM_VARIABLES, "num_values": NUM_VALUES,
                               "temporary_variable": source.temporary_variable,
                               "scored_registers": list(range(NUM_VARIABLES)),
                               "variants": [{**v.to_record(), "readable_operations": [op_text(op) for op in v.operations],
                                             "state_after_each_assignment": snapshots[v.complexity.value],
                                             "official_rendering": r.to_record()}
                                            for v,r in zip(variants,renders)]}
                print(f"length={length} seed={seed} checked", flush=True)
    rows = []
    for (length, family), counts in summary.items():
        rows.append({"extra_assignments": length, "family": family, **counts,
                     "ordinary_error_survival_rate": counts["replays_with_ordinary_error"]/counts["omission_replays"],
                     "ordinary_error_survival_percent": 100*counts["replays_with_ordinary_error"]/counts["omission_replays"],
                     "mean_ordinary_mismatches": counts["ordinary_mismatch_sum"]/counts["omission_replays"],
                     "all_register_error_survival_rate": counts["replays_with_any_register_error"]/counts["omission_replays"]})
    json_write(RESULTS / "summary.json", rows)
    keys = sorted({k for row in rows for k in row})
    with (RESULTS / "summary.csv").open("w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)
    json_write(RESULTS / "fixture_seed0_updates8.json", fixture)
    json_write(RESULTS / "eager_copy_check.json", eager)
    provenance = {"upstream_repository": "https://github.com/allenai/state-bench",
                  "commit": commit, "license": "Apache-2.0",
                  "run_utc": datetime.now(timezone.utc).isoformat(),
                  "python": sys.version, "platform": platform.platform(),
                  "seeds": SEEDS, "extra_primitive_assignments": LENGTHS,
                  "ordinary_variables": NUM_VARIABLES, "scratch_registers": 1,
                  "num_values": NUM_VALUES, "distinct_initial_values": True,
                  "aperiodic_constants_min_max": [1,1], "filler_proportion": 0,
                  "omission_policy": "Every post-initialization primitive assignment is deleted once in a separate replay. This includes TMP loads and individual swap assignments, not whole swaps.",
                  "score": "Any mismatch among the five ordinary final registers; TMP excluded. All-register supplementary results also saved.",
                  "not_model_evaluation": True, "model_calls": 0,
                  "scope": "Small deterministic audit of unmodified official generator/evaluator; settings differ from paper model evaluations.",
                  "invariant_assertions": dict(invariants)}
    json_write(RESULTS / "provenance.json", provenance)
    source = (ROOT / "run_audit.py").read_text(encoding="utf-8")
    numbered = "\n".join(f"{i:03}  {line}" for i,line in enumerate(source.splitlines(),1))
    (RESULTS / "source-code.html").write_text("<!doctype html><html lang='en'><meta charset='utf-8'><title>StateBench deletion audit source</title><style>body{background:#101720;color:#d9e7ef;font:16px/1.55 Consolas,monospace;padding:32px}h1{font:700 28px system-ui;color:#8ae9d0}p{font:16px system-ui;max-width:1000px}pre{white-space:pre-wrap}code{tab-size:4}</style><h1>Replay one missing assignment</h1><p>Official StateBench generator and evaluator, commit "+PIN[:12]+". Independent interpreter cross-checks every replay. No language model is called.</p><pre><code>"+html.escape(numbered)+"</code></pre></html>",encoding="utf-8")
    fixture_lines=[]
    by_family={v["complexity"]:v for v in fixture["variants"]}
    for index in range(NUM_VARIABLES+1+8):
        p=by_family["periodic"]
        fixture_lines.append(f"{index+1:02}  {p['readable_operations'][index]:18}  "+str(p["state_after_each_assignment"][index]))
    fixture_html="<!doctype html><html lang='en'><meta charset='utf-8'><title>Actual StateBench trace</title><style>body{margin:0;background:#101720;color:#d9e7ef;font:20px/1.7 Consolas,monospace;padding:48px}h1{font:700 34px system-ui;color:#8ae9d0}p{font:20px/1.5 system-ui;max-width:1000px}small{color:#9cb0c1}pre{padding:28px;background:#182432;border:1px solid #375466;border-radius:16px;display:inline-block}</style><h1>One actual generated trace</h1><p>Seed 0 · five ordinary registers + TMP · 8 update assignments · 32 values</p><small>Columns: assignment / state [a, b, c, d, e, TMP] immediately afterward</small><br><pre>"+html.escape("\n".join(fixture_lines))+"</pre><p>Copies happen immediately. A later change to the source register does not change a value already copied.</p><small>Upstream commit "+PIN[:12]+" · Apache-2.0 · deterministic replay · no model calls</small></html>"
    (RESULTS / "actual-trace.html").write_text(fixture_html,encoding="utf-8")
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in RESULTS.iterdir() if p.is_file() and p.name!="sha256.json"}
    json_write(RESULTS / "sha256.json", hashes)
    print(json.dumps({"summary":rows,"assertions":dict(invariants)},indent=2))


if __name__ == "__main__":
    main()
