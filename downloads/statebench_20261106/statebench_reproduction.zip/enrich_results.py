"""Summarize audit controls and add one deletion example to the real fixture."""
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

from state_bench.model import StateTrackingInstance
from state_bench.semantics import evaluate

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
counts = defaultdict(Counter)
with (RESULTS / "omission_replays.csv").open(encoding="utf-8", newline="") as f:
    for row in csv.DictReader(f):
        for policy, score_key in [("all_updates_score_ordinary5", "ordinary_mismatches"),
                                  ("all_updates_score_all6", "all_register_mismatches"),
                                  ("ordinary_targets_only_score_ordinary5", "ordinary_mismatches")]:
            if policy.startswith("ordinary_targets_only") and int(row["omitted_target"]) == 5:
                continue
            c = counts[(int(row["extra_assignments"]), row["family"], policy)]
            c["omission_replays"] += 1
            c["error_replays"] += int(row[score_key]) > 0
rows = [{"extra_assignments": length, "family": family, "policy": policy,
         **c, "error_percent": 100*c["error_replays"]/c["omission_replays"]}
        for (length,family,policy),c in counts.items()]
(RESULTS / "controls.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8")
with (RESULTS / "controls.csv").open("w",encoding="utf-8",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
fixture_path = RESULTS / "fixture_seed0_updates8.json"
fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
examples=[]
omitted_index=8
for record in fixture["variants"]:
    instance=StateTrackingInstance.from_record(record)
    actual=evaluate(num_variables=instance.num_registers,num_values=instance.num_values,
                    operations=instance.operations[:omitted_index]+instance.operations[omitted_index+1:])
    examples.append({"family":instance.complexity.value,
                     "omitted_operation":record["readable_operations"][omitted_index],
                     "expected_all6":list(instance.final_state),"actual_all6":list(actual),
                     "ordinary5_mismatches":sum(a!=b for a,b in zip(actual[:5],instance.final_state[:5])),
                     "all6_mismatches":sum(a!=b for a,b in zip(actual,instance.final_state))})
fixture["single_omission_example"]={"operation_index_0based":omitted_index,
                                    "update_index_1based":3,
                                    "examples":examples,
                                    "note":"The third update targets TMP. This exposes the scoring choice: periodic can propagate a TMP error to ordinary registers; solvable cannot."}
ordinary_examples=[]
ordinary_omitted_index=7
for record in fixture["variants"]:
    instance=StateTrackingInstance.from_record(record)
    actual=evaluate(num_variables=instance.num_registers,num_values=instance.num_values,
                    operations=instance.operations[:ordinary_omitted_index]+instance.operations[ordinary_omitted_index+1:])
    ordinary_examples.append({"family":instance.complexity.value,
                              "omitted_operation":record["readable_operations"][ordinary_omitted_index],
                              "expected_all6":list(instance.final_state),"actual_all6":list(actual),
                              "ordinary5_mismatches":sum(a!=b for a,b in zip(actual[:5],instance.final_state[:5]))})
fixture["ordinary_target_omission_example"]={"operation_index_0based":ordinary_omitted_index,
                                            "update_index_1based":2,
                                            "examples":ordinary_examples,
                                            "note":"The second update writes b <- 10 in both periodic and aperiodic traces. Skipping it leaves periodic c=2 instead of 10, but aperiodic later writes the required c=10 directly and recovers."}
fixture_path.write_text(json.dumps(fixture,indent=2)+"\n",encoding="utf-8")
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in RESULTS.iterdir() if p.is_file() and p.name!="sha256.json"}
(RESULTS / "sha256.json").write_text(json.dumps(hashes,indent=2)+"\n",encoding="utf-8")
for row in rows:
    if row["extra_assignments"]==512:
        print(json.dumps(row))
