# StateBench deterministic trace audit

This work executes the **official generator, derivation functions, renderer and evaluator** from `allenai/state-bench` at commit `5b333b8d426638d8825f40efe8a508c20eb85730` (Apache-2.0). Upstream source files are unmodified. It does **not** call a language model, reproduce the paper's model evaluations, measure model accuracy or establish a new ranking of algebraic families.

## Reproduce on Windows

From this directory (Python >=3.12; actual run used CPython 3.14.7):

```powershell
git clone https://github.com/allenai/state-bench.git vendor/state-bench
git -C vendor/state-bench checkout 5b333b8d426638d8825f40efe8a508c20eb85730
uv venv .venv
uv pip install --python .venv/Scripts/python.exe -e vendor/state-bench pytest
.venv/Scripts/python.exe run_audit.py
.venv/Scripts/python.exe enrich_results.py
.venv/Scripts/state-bench.exe config check mini-experiment.yaml
.venv/Scripts/state-bench.exe build mini-experiment.yaml --workers 1
.venv/Scripts/python.exe -m pytest vendor/state-bench/tests/test_semantics.py vendor/state-bench/tests/test_solvable.py -q
```

For an existing clone omit the clone command. Installed dependency versions are preserved in `environment-freeze.txt`. Repository and environment are local under this experiment directory; there are no external writes.

## Scope and settings

- Seeds 0–31; 5 ordinary variables plus the generator's TMP scratch register; 32 values; distinct ordinary initial values.
- Four separate lengths: 8, 32, 128, 512 **post-initialization primitive assignments**, plus six initial constant assignments. Three primitive assignments make a swap; the generator can add scratch-only loads to consume the exact requested budget.
- One constant reset per source (min=max=1), the upstream generator's placement policy. No filler and no model prompt/evaluation harness.
- Every periodic source is derived into r-trivial, aperiodic, solvable and periodic with the official `derive_variants`. The integer-code-modular formatter uses literal zero-based values so modular arithmetic is truthful.
- 128 source traces, 512 family instances, 87,040 separate omission replays. In each replay exactly one post-initialization primitive assignment is skipped, including TMP operations. Initialization is never deleted.

## Checks actually performed

- Identical seed/settings regenerate identical source instances (128 checks).
- Periodic, solvable and aperiodic have identical register values **after every baseline assignment**, including TMP (22,528 source-step comparisons).
- All four preserve assignment count, target order, query and surface vocabulary (128 family-set checks).
- The r-trivial variant repeats each target's first value; its final state is **not** generally the other three families' final state (128 checks).
- Official final evaluation agrees with a small independent eager-copy interpreter for all 512 baseline instances and all 87,040 omission replays.
- A separate four-assignment copy check returns `(5, 9)`: copying b=5 into a and later writing b=9 leaves a=5. No persistent alias is created.
- The official CLI validates `mini-experiment.yaml` and builds two source traces × four families = eight canonical/rendered rows.

## Read the numbers carefully

`summary.csv` reports the fraction of omission positions which leave **at least one of the five ordinary final registers wrong**, pooled across 32 deterministic seeds. This is an error-survival fraction for this deletion policy; it is not model accuracy or an inference about real-world error frequency. Replays from the same trace are correlated. No statistical confidence claim is made.

`controls.csv` also reports (1) scoring all six registers, and (2) deleting only updates targeting ordinary registers. These controls matter: a missed TMP self-increment in the solvable family stays in TMP, whereas a missed periodic TMP copy can later affect an ordinary register. Excluding TMP from scoring therefore affects the family comparison. The r-trivial 0% is structural: all post-initialization assignments repeat each target's initial value. Aperiodic literals can overwrite a missing earlier assignment. These properties explain the measured behavior and must not be promoted into an algebraic-complexity or LLM-performance ranking.

Settings are deliberately small and differ from published model-evaluation distributions. The fixed reset count, distinct starting values, variable count, omission positions, primitive-vs-swap granularity, and scoring registers all influence the result. Treat the table as a concrete dependency illustration, not a universal trend.

## Files

- `results/provenance.json`: source commit, Python/platform, settings, invariant counts.
- `results/canonical_family_sets.jsonl`: all 128 source/four-family records.
- `results/omission_replays.csv`: 87,040 position-level results.
- `results/summary.json` / `.csv`: main aggregate results.
- `results/controls.json` / `.csv`: alternate omission/score controls.
- `results/fixture_seed0_updates8.json`: one actual generated trace, four variants, every baseline state, official surface renderings, and a shared-position omission example.
- `results/actual-trace.html`: screenshot-ready actual trace and state table.
- `results/source-code.html`: screenshot-ready numbered audit source.
- `results/eager_copy_check.json`: explicit copy-versus-alias example (a separate hand-written check, not generated dataset output).
- `results/sha256.json`: hashes for result files.
- `cli-generated/`: output from the actual upstream CLI build.
- `official-tests.log`, `audit-run.log`, `cli-build.log`: execution logs.

The upstream Apache-2.0 license and third-party notices remain in `vendor/state-bench`.
