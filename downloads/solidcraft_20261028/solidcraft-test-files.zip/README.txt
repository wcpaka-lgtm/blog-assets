SolidCraft v0.24.1 reproducible example / Open Source Factory / 2026-10-28

This is a digital geometry inspection exercise. It has not been printed, fitted, or load-tested.
The model is adapted from examples/bracket.json in SolidCraft v0.24.1. The example fillet is omitted.
Upstream: https://github.com/tangency-labs/solidcraft/blob/v0.24.1/examples/bracket.json
Upstream licensing: MIT OR Apache-2.0; licence texts are included in this archive.

1. Open bracket-60.solidcraft in SolidCraft v0.24.1 or newer.
2. Change the width parameter from 60 mm to 80 mm.
3. Inspect the two hole centres, 15 and 45 mm from the same end. The far end-to-centre distance becomes 35 mm.
4. Keep the native design for its feature history. STEP exchanges the solid geometry. STL/3MF deliver meshes.

CLI reproduction:
solidcraft-cli run bracket-60.json --save bracket-60.solidcraft --out bracket-60.step
solidcraft-cli run resize-80.json --in bracket-60.solidcraft --save bracket-80.solidcraft --out bracket-80.stl

한글 안내: 이 파일은 디지털 형상 검사 연습용입니다. 실물 출력·조립·하중 시험은 하지 않았습니다.
원본 설계를 열고 width를 60 mm에서 80 mm로 바꾼 다음, 양 끝에서 구멍 중심까지의 거리를 확인하세요.
구멍 중심은 같은 끝에서 15mm와 45mm로 고정되어 있어 먼 쪽 여백이 15mm에서 35mm로 바뀝니다.
원본 설계는 수정 이력 보관용이며, STEP과 메시 파일도 함께 제공합니다.
