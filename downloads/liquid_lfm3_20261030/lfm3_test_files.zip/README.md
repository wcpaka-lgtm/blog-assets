# LFM3 local extraction and routing checks

12 author-written synthetic fixtures per mode. Not a standardized benchmark, representative accuracy estimate, real support workflow, or tool-execution test. Input/expected values were fixed before runs; no per-case corrective retries. No model fine-tuning.

Runtime: official llama.cpp b11960 (the build identified by v0.8.0), Windows CPU x64. Intel Core i5-10400F;6 CPU threads; no GPU offload;4096-token context; one slot. Temperature0.1, top-k50, repetition penalty1.1, seed42, max output512. Chat template enable_thinking=false. The server reported fingerprint b11960-8642541b2. Short prompts only, not a full-context test. Prefix caches may be reused by the runtime.

Weights: https://huggingface.co/LiquidAI/LFM3-1.7B-GGUF/resolve/bad5729bba61d076fff20d2548e62526665af215/LFM3-1.7B-Q4_K_M.gguf
Bytes:1099627808
SHA256:3793e1e6e2266919d6e015287221b41100175a98eddaba92e111aed3b05c93c4

Runtime: https://github.com/ggml-org/llama.cpp/releases/tag/b11960
Windows CPU zip SHA256:73f962f82850d244db47eaacb9d913637027b82399124324298576d58c5f4287

Start llama-server from the extracted official runtime using a local GGUF path:

    llama-server -m LFM3-1.7B-Q4_K_M.gguf --host 127.0.0.1 --port 11440 -c 4096 -np 1 -t 6 -ngl 0 --jinja

Use spaces between each flag and value (for example `--host 127.0.0.1 --port 11440 -c 4096 -np 1 -t 6 -ngl 0`). Pass the JSON chat-template option `enable_thinking=false` as supported by your shell; the script also includes it on each request.

Run with Python3 using only its standard library:

    python run_checks.py --mode raw
    python run_checks.py --mode schema

The second pass adds response_format JSON Schema: required keys/types, no additional properties; routing uses the same enum already stated in the prompt. Expected order numbers, dates and quantities are not embedded in the schema. The complete content must parse directly with json.loads and equal the expected object (key order is ignored). No fence stripping or post-hoc answer repair is counted.

Results in this exact setup: raw4/12 exact parsed objects (extraction0/8, routing4/4); schema12/12 (extraction8/8, routing4/4). Raw extraction outputs contained trailing fences; two also had an extra field. These are application-format failures, not proof of a general33% model accuracy. A schema does not guarantee correct facts.

Files contain synthetic data only. Local filesystem model paths in server responses were replaced with the public model filename for privacy. Other generated content is unedited. Model weights and runtime binaries are not redistributed in this bundle; their own licenses apply.
