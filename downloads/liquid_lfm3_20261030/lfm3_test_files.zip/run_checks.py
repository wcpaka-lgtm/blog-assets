"""Small synthetic extraction/routing check. This is not a standardized benchmark.
Requires the pinned llama.cpp server on --base and the official Q4_K_M model. No external tools are executed.
"""
import argparse,json,time,re,urllib.request,hashlib,statistics
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--base',default='http://127.0.0.1:11440');parser.add_argument('--max-cases',type=int,default=12);parser.add_argument('--mode',choices=['raw','schema'],default='raw');args=parser.parse_args()
R=Path(__file__).resolve().parent;T=R/'tests';T.mkdir(exist_ok=True)
MODEL='hf.co/LiquidAI/LFM3-1.7B-GGUF:Q4_K_M'
def api(path,body):
 req=urllib.request.Request(args.base+path,data=json.dumps(body,ensure_ascii=False).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=360) as res:return json.load(res)
cases=[]
extract_system='Extract only facts stated in the record. Return exactly one JSON object with keys order_id (string or null), quantity (integer or null), currency (string or null), ship_date (YYYY-MM-DD string or null). Use null for missing facts; do not infer a date from unrelated text. No prose, no markdown.'
records=[
 ('EN-01','en','Order OSF-301 has 3 filament spools. Currency USD. Ship date: 2026-11-04.',{'order_id':'OSF-301','quantity':3,'currency':'USD','ship_date':'2026-11-04'}),
 ('EN-02','en','Order OSF-302: two nozzle kits, paid in EUR. The invoice was issued on 2026-10-27. The dispatch date has not been set.',{'order_id':'OSF-302','quantity':2,'currency':'EUR','ship_date':None}),
 ('EN-03','en','Correction for OSF-303: quantity was 8, now changed to 5. Currency GBP. Confirmed ship date 2026-11-06.',{'order_id':'OSF-303','quantity':5,'currency':'GBP','ship_date':'2026-11-06'}),
 ('EN-04','en','Please quote four replacement fans. No order number has been assigned. Currency CAD. Shipment is pending, no date.',{'order_id':None,'quantity':4,'currency':'CAD','ship_date':None}),
 ('KO-01','ko','주문 OSF-401은 필라멘트 3개입니다. 결제 통화는 KRW이고 출하일은 2026-11-04입니다.',{'order_id':'OSF-401','quantity':3,'currency':'KRW','ship_date':'2026-11-04'}),
 ('KO-02','ko','OSF-402 주문: 노즐 키트 두 개, 통화는 JPY입니다. 청구서 발행일은 2026-10-27이며 출하일은 아직 정하지 않았습니다.',{'order_id':'OSF-402','quantity':2,'currency':'JPY','ship_date':None}),
 ('KO-03','ko','OSF-403 정정: 수량 8개가 아니라 최종 5개입니다. 통화는 KRW, 확정 출하일은 2026-11-06입니다.',{'order_id':'OSF-403','quantity':5,'currency':'KRW','ship_date':'2026-11-06'}),
 ('KO-04','ko','교체용 팬 네 개의 견적을 요청합니다. 주문 번호는 아직 없고 통화는 USD입니다. 출하 날짜는 미정입니다.',{'order_id':None,'quantity':4,'currency':'USD','ship_date':None}),
]
for cid,lang,record,expected in records:cases.append({'id':cid,'language':lang,'task':'extraction','system':extract_system,'input':record,'expected':expected})
route_system='Classify the support request by its actual requested resolution. Allowed categories: billing (payment, invoice, refund), delivery (parcel, address, dispatch), technical (software or device malfunction). Return exactly one JSON object with the single key category. No prose or markdown.'
for cid,lang,text,category in [
 ('EN-R1','en','The parcel arrived. This is not a delivery problem: the app crashes every time I connect the device. Please fix the software.','technical'),
 ('EN-R2','en','The device works and delivery was fine. I was billed twice for the same order; please refund the duplicate payment.','billing'),
 ('KO-R1','ko','결제는 정상입니다. 앱 오류도 없습니다. 택배가 잘못된 주소로 갔으니 배송지를 바로잡아 주세요.','delivery'),
 ('KO-R2','ko','배송은 이미 끝났습니다. 연결할 때 프로그램이 계속 종료됩니다. 결제가 아니라 프로그램 문제를 해결해 주세요.','technical')]:
 cases.append({'id':cid,'language':lang,'task':'routing','system':route_system,'input':text,'expected':{'category':category}})
(T/'cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2),encoding='utf8')
props=json.load(urllib.request.urlopen(args.base+'/props'));(T/'llama-props.json').write_text(json.dumps(props,ensure_ascii=False,indent=2),encoding='utf8')
options={'temperature':0.1,'top_k':50,'repeat_penalty':1.1,'seed':42,'max_tokens':512,'chat_template_kwargs':{'enable_thinking':False}}
settings={'model':MODEL,'runtime':'llama.cpp b11960 / v0.8.0','context_tokens':4096,'options':options,'json_grammar':False,'retries_per_case':0,'order':'fixed; one independent conversation per case','machine':'Intel Core i5-10400F; CPU-only; 6 inference threads; Windows','fixture_warning':'12 small author-written synthetic checks. Not representative accuracy, tool execution, or an agent benchmark.'}
settings.update(mode=args.mode,json_grammar=args.mode=='schema')
(T/f'settings_{args.mode}.json').write_text(json.dumps(settings,indent=2),encoding='utf8')
results=[]
for case in cases[:args.max_cases]:
 body={'model':MODEL,'messages':[{'role':'system','content':case['system']},{'role':'user','content':case['input']}],'stream':False,**options}
 if args.mode=='schema':
  props={'order_id':{'type':['string','null']},'quantity':{'type':['integer','null']},'currency':{'type':['string','null']},'ship_date':{'type':['string','null']}} if case['task']=='extraction' else {'category':{'type':'string','enum':['billing','delivery','technical']}}
  schema={'type':'object','properties':props,'required':list(props),'additionalProperties':False}
  body['response_format']={'type':'json_schema','json_schema':{'name':case['task'],'strict':True,'schema':schema}}
 start=time.perf_counter();result=api('/v1/chat/completions',body);elapsed=time.perf_counter()-start
 raw=result['choices'][0]['message'].get('content','');parsed=None
 try:parsed=json.loads(raw);valid=True
 except Exception:valid=False
 item={'id':case['id'],'task':case['task'],'language':case['language'],'input':case['input'],'expected':case['expected'],'raw_content':raw,'parsed':parsed,'valid_json':valid,'exact_match':parsed==case['expected'],'wall_seconds':elapsed,'response':result}
 item['request']=body
 results.append(item);(T/f'results_{args.mode}.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps({'id':case['id'],'exact_match':item['exact_match'],'valid_json':valid,'seconds':round(elapsed,2),'content':raw},ensure_ascii=False),flush=True)
summary={'mode':args.mode,'cases':len(results),'exact_matches':sum(x['exact_match'] for x in results),'valid_json':sum(x['valid_json'] for x in results),'by_task':{},'by_language':{},'median_request_wall_seconds':statistics.median(x['wall_seconds'] for x in results),'generated_tokens_per_second':[]}
for key in ['task','language']:
 for value in sorted(set(x[key] for x in results)):
  group=[x for x in results if x[key]==value];summary['by_'+key][value]={'passed':sum(x['exact_match'] for x in group),'cases':len(group)}
for x in results:
 r=x['response'];timing=r.get('timings',{});rate=timing.get('predicted_per_second')
 if rate is not None:summary['generated_tokens_per_second'].append(rate)
summary['median_generated_tokens_per_second']=statistics.median(summary['generated_tokens_per_second']) if summary['generated_tokens_per_second'] else None
(T/f'summary_{args.mode}.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary),flush=True)
